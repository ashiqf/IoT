using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Microsoft.Azure.Devices;
using System.Text;
using System.Net;


namespace FunctionApp_IoT
{
    public static class Function1
    {
        static ServiceClient serviceClient;
        static string connectionString = "HostName=YourIoTHub.azure-devices.net;SharedAccessKeyName=iothubowner;SharedAccessKey=yoursharedaccesskey";
        static string targetDevice = "Your device ID";
        [FunctionName("Function1")]
        public static IActionResult Run(
            [HttpTrigger(AuthorizationLevel.Function, "get", "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            log.LogInformation("C# HTTP trigger function processed a request.");

            string name = req.Query["name"];

            serviceClient = ServiceClient.CreateFromConnectionString(connectionString);

            SendCloudToDeviceMessageAsync(name).Wait();
            
            return new OkObjectResult(new { status = "Light turned On or Off" });
            
        }
        private async static Task SendCloudToDeviceMessageAsync(string condition)
        {
            var commandMessage = new
             Message(Encoding.ASCII.GetBytes(condition));
            await serviceClient.SendAsync(targetDevice, commandMessage);
        }
    }

}
    
