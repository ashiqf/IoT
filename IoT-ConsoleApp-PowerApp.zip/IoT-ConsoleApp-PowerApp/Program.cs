﻿using System;
using System.Device.Gpio;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Azure.Devices.Client;
using Microsoft.Azure.Devices.Client.Exceptions;

namespace IoT_ConsoleApp_PowerApp
{
    class Program
    {
        private const string IotHubUri = "YourIoTHub.azure-devices.net";
        private const string deviceKey = "Your Key";
        private const string deviceId = "Your device ID";
        private const int Pin1 = 17;
	    private const int Pin2 = 18;

        private static CancellationToken _ct;

        static async Task Main(string[] args)
        {
            Console.WriteLine("Controlling Devices using IoT Hub from PowerApps");
            
            var cts = new CancellationTokenSource();
            _ct = cts.Token;

            Console.CancelKeyPress += (sender, eventArgs) =>
            {
                Console.WriteLine($"{DateTime.Now} > Cancelling...");
                cts.Cancel();

                eventArgs.Cancel = true;
            };

            try
            {
                var t = Task.Run(Run, cts.Token);
                await t;
            }
            catch (IotHubCommunicationException)
            {
                Console.WriteLine($"{DateTime.Now} > Operation has been cancelled.");
            }
            catch (OperationCanceledException)
            {
                Console.WriteLine($"{DateTime.Now} > Operation has been cancelled.");
            }
            finally
            {
                cts.Dispose();
            }

            Console.ReadKey();
        }

        private static async Task Run()
        {
            using var deviceClient = DeviceClient.Create(IotHubUri, new DeviceAuthenticationWithRegistrySymmetricKey(deviceId, deviceKey));
            using var controller = new GpioController();
            controller.OpenPin(Pin1, PinMode.Output);
	        controller.OpenPin(Pin2, PinMode.Output);

            Console.WriteLine($"Azure IoT Hub: {IotHubUri}");
            Console.WriteLine($"Device ID: {deviceId}");

            Console.WriteLine("GPIO pin 17 & 18 enabled for use");

            while (!_ct.IsCancellationRequested)
            {
                Console.WriteLine($"{DateTime.Now} > Waiting for new messages");
                var receivedMessage = await deviceClient.ReceiveAsync(_ct);
                if (receivedMessage == null) continue;

                var msg = Encoding.ASCII.GetString(receivedMessage.GetBytes());
                Console.WriteLine($"{DateTime.Now} > Received message: {msg}");

                switch (msg)
                {
                    case "on1":
                        Console.WriteLine($"{DateTime.Now} > Turn on the first light.");
                        controller.Write(Pin1, PinValue.High);
                        break;
                    case "off1":
                        Console.WriteLine($"{DateTime.Now} > Turn off the first light.");
                        controller.Write(Pin1, PinValue.Low);
                        break;
		            case "on2":
                        Console.WriteLine($"{DateTime.Now} > Turn on the second light.");
                        controller.Write(Pin2, PinValue.High);
                        break;
                    case "off2":
                        Console.WriteLine($"{DateTime.Now} > Turn off the second light.");
                        controller.Write(Pin2, PinValue.Low);
                        break;
                    default:
                        Console.WriteLine($"Message not configured: {msg}");
                        break;
                }

                await deviceClient.CompleteAsync(receivedMessage, _ct);
            }
        }
    }
}
